clc
clear all

A=[1;2;3;4;5]; % 列向量
B=max(A,[],1);
B=max(A,[],2);