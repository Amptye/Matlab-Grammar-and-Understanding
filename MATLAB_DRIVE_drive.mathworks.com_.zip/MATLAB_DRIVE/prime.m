clc; % 清空命令行窗口
clear; % 清空工作区

%% 找一个函数，模拟乘法，看是否有类似素数的分布
f = @(a,b) (a*a + 3*a*b)/2;
% f = @(a,b) floor((a*a + 3*a*b)/2);
% f = @(a,b) ceil((a*a + 3*a*b)/2);

%% 1. 生成三角形阵列
clc;
% clear;
fprintf('1. 生成三角形阵列...\n');
n = 100;
product_Matrix = zeros(n, n);
newf_Matrix = zeros(n, n);

for i = 1:n
    for j = 1:i
        product_Matrix(i, j) = i * j;
        newf_Matrix(i, j) = f(i,j);
    end
    for j = (i+1):n
        newf_Matrix(i, j) = f(i,j);
    end
end

% 显示前5行
format shortG;
disp(newf_Matrix(1:5, 1:5));
format default;
%{
fprintf('三角形阵列前5行:\n');
for i = 1:5
    for j = 1:i
        fprintf('%4d ', product_Matrix(i, j));
    end
    fprintf('\n');
end
fprintf('\n');
%}
%% 2. 生成布尔素数数组
clc;
% clear;
fprintf('2. 生成布尔素数数组...\n');
maxNum = 10000;
isPrime = true(1, maxNum);
isPrime(1) = false;  % 1不是素数
newTimes = zeros(1, maxNum);
zeroTime = false(1, maxNum);
oneTime = false(1, maxNum);
zeroOrOneTime = false(1, maxNum);
twoTime = false(1, maxNum);
zotTime = false(1, maxNum);

% 使用筛法求素数
for p = 2:floor(sqrt(maxNum))
    if isPrime(p)
        % 将p的倍数标记为非素数
        isPrime(p*p:p:maxNum) = false;
    end
end
for i = 1:floor((maxNum*2-1)/3)
    for j = 1:floor((maxNum*2-1)/3)
        pos = f(i,j);
        if pos == fix(pos) && pos <= maxNum
            newTimes(pos) = newTimes(pos) + 1;
        end
    end
end
for i = 1:maxNum
    if newTimes(i) == 0
        zeroTime(i) = true;
        zeroOrOneTime(i) = true;
        zotTime(i) = true;
    elseif newTimes(i) == 1
        oneTime(i) = true;
        zeroOrOneTime(i) = true;
        zotTime(i) = true;
    elseif newTimes(i) == 2
        twoTime(i) = true;
        zotTime(i) = true;
    end
end
figure('Position', [100, 100, 1000, 400]);
scatter(1:maxNum, newTimes, 30, newTimes, 'filled');
%{
for i = 1:maxNum
    if newTimes(i) == 0
        fprintf('    0');
    elseif newTimes(i) == 1
        fprintf('\033[41m    1\033[0m');
        % ColorPrint.cprintf('    1', 'blue');
    else
        fprintf('\033[41m    1\033[0m');
        %ColorPrint.cprintf(newTimes(i), 'red');
    end
end
%}

% 统计素数数量
primeCount = sum(isPrime);
% disp(isPrime);
fprintf('1~10000中共有 %d 个素数\n\n', primeCount);
fprintf('1~10000中共有 %d 个数只对应f的零个输入\n\n', sum(zeroTime));
fprintf('1~10000中共有 %d 个数只对应f的一个输入\n\n', sum(oneTime));
fprintf('1~10000中共有 %d 个数对应f的大于一个输入\n\n', sum(zeroOrOneTime));
fprintf('1~10000中共有 %d 个数只对应f的两个输入\n\n', sum(twoTime));
fprintf('1~10000中共有 %d 个数对应f的大于两个输入\n\n', sum(zotTime));
%}
%% 3. 生成素数比例数组
clc;
% clear;
fprintf('3. 生成素数比例数组...\n');
primeRatio = zeros(1, maxNum);
cumulativePrimes = 0;

for b = 1:maxNum
    if isPrime(b)
        cumulativePrimes = cumulativePrimes + 1;
    end
    primeRatio(b) = cumulativePrimes / b;
end
% disp(primeRatio);

% 绘制素数比例变化图
figure;
plot(1:maxNum, primeRatio, 'b-', 'LineWidth', 1.5);
xlabel('b (1~10000)');
ylabel('素数比例 (前b个数中素数个数/b)');
title('素数比例变化图');
grid on;
hold on;

% 标记一些特定点
samplePoints = [10, 100, 1000, 10000];
for k = samplePoints
    plot(k, primeRatio(k), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
    text(k, primeRatio(k)+0.01, sprintf('b=%d\n%.4f', k, primeRatio(k)), ...
        'FontSize', 9, 'HorizontalAlignment', 'center');
end
hold off;

% 打印特定点的值
fprintf('特定b值的素数比例:\n');
fprintf('b=10: %.4f\n', primeRatio(10));
fprintf('b=100: %.4f\n', primeRatio(100));
fprintf('b=1000: %.4f\n', primeRatio(1000));
fprintf('b=10000: %.4f\n\n', primeRatio(10000));
%}
%% 4. 生成1~10000的全部素数数组
clc;
% clear;
fprintf('4. 生成1~10000的全部素数数组...\n');
primes = find(isPrime);

% 显示前20个和后20个素数
fprintf('前20个素数:\n');
fprintf('%5d', primes(1:20));
fprintf('\n\n');

fprintf('最后20个素数:\n');
fprintf('%5d', primes(end-19:end));
fprintf('\n\n');

fprintf('素数总数: %d\n', length(primes));

%% 额外：素数分布的统计分析
fprintf('\n额外分析 - 素数间距统计:\n');
if length(primes) > 1
    primeGaps = diff(primes);
    fprintf('最小素数间距: %d\n', min(primeGaps));
    fprintf('最大素数间距: %d\n', max(primeGaps));
    fprintf('平均素数间距: %.2f\n', mean(primeGaps));
end

%% 将结果保存到工作区变量
% 保存所有结果到工作区
assignin('base', 'product_Matrix', product_Matrix);
assignin('base', 'isPrime', isPrime);
assignin('base', 'primeRatio', primeRatio);
assignin('base', 'allPrimes', primes);

fprintf('\n所有计算已完成！\n');
fprintf('结果已保存到工作区变量:\n');
fprintf('  product_Matrix: 三角形阵列 (100×100)\n');
fprintf('  isPrime: 布尔素数数组 (1×10000)\n');
fprintf('  primeRatio: 素数比例数组 (1×10000)\n');
fprintf('  allPrimes: 全部素数数组\n');