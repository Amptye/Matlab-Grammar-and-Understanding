clc
clear all

map_width = 300;
map_height = 300;

lambda=32.8; %波长
N=5;
charger1_x=50;%charger1位置450:-240;-180||450:;-270
charger1_y=50;
charger2_x=250; %charger2位置-192;180
charger2_y=50;
charger3_x=150; %charger3位置72;132
charger3_y=250;

xs = randi(map_width, 1, 3);
ys = randi(map_height, 1, 3);
charger1_x=xs(1);
charger1_y=ys(1);
charger2_x=xs(2);
charger2_y=ys(2);
charger3_x=xs(3);
charger3_y=ys(3);

A_1=1; %charger1的振幅
A_2=1; %charger2的振幅
A_3=1; %charger3的振幅

alpha=10.9;
beta=9.9;
phi_1_0=100;
phi_2_0=100;
P_0=3000;
PP=[];
PPP=[];
x=0:1:300;
y=0:1:300;

f1 = figure(1);

% set(gcf,'Position',[50/0.277 50/0.277 160/0.277 160/0.277]);

% 按列计算每个点的振幅、功率
for i=0:0.6:300
    for j=0:0.6:300
        sensor_x=i; %从列遍历，matlab reshape按列存放
        sensor_y=j;
        %每个sensor到各个charger的距离
        d_1=sqrt((sensor_x-charger1_x)^2+(sensor_y-charger1_y)^2);
        d_2=sqrt((sensor_x-charger2_x)^2+(sensor_y-charger2_y)^2);
        d_3=sqrt((sensor_x-charger3_x)^2+(sensor_y-charger3_y)^2);

        phi_1=(24/24)*2*pi+2*pi*d_1/lambda;
        phi_2=(24/24)*2*pi+2*pi*d_2/lambda;
        phi_3=(24/24)*2*pi+2*pi*d_3/lambda;
    
        P_1 = P_0 * (alpha / (beta + d_1) ^2);     
        P_2 = P_0 * (alpha / (beta + d_2) ^2);
        P_3 = P_0 * (alpha / (beta + d_3) ^2);
        P_sum=P_1 + P_2 + P_3;
        P_12 = sqrt(P_1 * P_2)*cos(phi_1 - phi_2);
        P_13 = sqrt(P_1 * P_3)*cos(phi_1 - phi_3);
        P_23 = sqrt(P_2 * P_3)*cos(phi_2 - phi_3);
        P =P_sum+2 *(P_12+P_13+P_23);
        
        if P < 0.1
            P=0.1;
        end
        P_log=log10(P);
        PP(end+1)=P_log;
        PPP(end+1)=P;
    end
end

disp(PP);

P_fin=reshape(PP,501,501);
PP_fin=reshape(PPP,501,501);

imagesc(x,y,P_fin);
% surf(P_fin);
hold on;
% 等高线
x = linspace(0, 300, size(P_fin, 1));
y = linspace(0, 300, size(P_fin, 2));
% contour(y, x, P_fin, [0.1:0.2:max(PP)], 'LineColor', 'k');

PP2=[];
PPP2=[];

% % 按列计算每个点的振幅、功率
% for i=0:0.6:300
%     for j=0:0.6:300
%         sensor_x=i; %从列遍历，matlab reshape按列存放
%         sensor_y=j;
%         %每个sensor到各个charger的距离
%         d_1=sqrt((sensor_x-charger1_x)^2+(sensor_y-charger1_y)^2);
%         d_2=sqrt((sensor_x-charger2_x)^2+(sensor_y-charger2_y)^2);
%         d_3=sqrt((sensor_x-charger3_x)^2+(sensor_y-charger3_y)^2);
% 
%         phi_1=(24/24)*2*pi+2*pi*d_1/lambda;
%         phi_2=(24/24)*2*pi+2*pi*d_2/lambda;
%         phi_3=(24/24)*2*pi+2*pi*d_3/lambda;
%     
%         P_1 = P_0 * (alpha / (beta + d_1) ^2);     
%         P_2 = P_0 * (alpha / (beta + d_2) ^2);
%         P_3 = P_0 * (alpha / (beta + d_3) ^2);
%         P2=P_1 + P_2 + P_3;
%         
%         if P < 0.1
%             P=0.1;
%         end
%         P2_log=log10(P2);
%         PP2(end+1)=P2_log;
%         PPP2(end+1)=P2;
%     end
% end
% 
% P_fin2=reshape(PP2,501,501);
% 
% x = linspace(0, 300, size(P_fin2, 1));
% y = linspace(0, 300, size(P_fin2, 2));
% % contour(y, x, P_fin2, [0.1:0.2:max(PP)], 'LineColor', 'k');

% 按列计算每个点的振幅、功率


PP_1=[];
PP_2=[];
PP_3=[];

for i=0:0.6:300
    for j=0:0.6:300
        sensor_x=i; %从列遍历，matlab reshape按列存放
        sensor_y=j;
        %每个sensor到各个charger的距离
        d_1=sqrt((sensor_x-charger1_x)^2+(sensor_y-charger1_y)^2);
        d_2=sqrt((sensor_x-charger2_x)^2+(sensor_y-charger2_y)^2);
        d_3=sqrt((sensor_x-charger3_x)^2+(sensor_y-charger3_y)^2);

        phi_1=(24/24)*2*pi+2*pi*d_1/lambda;
        phi_2=(24/24)*2*pi+2*pi*d_2/lambda;
        phi_3=(24/24)*2*pi+2*pi*d_3/lambda;
    
        P_1 = P_0 * (alpha / (beta + d_1) ^2);     
        P_2 = P_0 * (alpha / (beta + d_2) ^2);
        P_3 = P_0 * (alpha / (beta + d_3) ^2);

        P_log_1=log10(P_1);
        PP_1(end+1)=P_log_1;
        P_log_2=log10(P_2);
        PP_2(end+1)=P_log_2;
        P_log_3=log10(P_3);
        PP_3(end+1)=P_log_3;
    end
end

P_fin_1=reshape(PP_1,501,501);
P_fin_2=reshape(PP_2,501,501);
P_fin_3=reshape(PP_3,501,501);

x = linspace(0, 300, size(P_fin_1, 1));
y = linspace(0, 300, size(P_fin_1, 2));
contour(y, x, P_fin_1, [0.1:0.25:max(PP_1)], 'LineWidth', 1.5,'LineColor','w','LineStyle',':');
contour(y, x, P_fin_2, [0.1:0.25:max(PP_2)], 'LineWidth', 1.5,'LineColor','w','LineStyle',':');
contour(y, x, P_fin_3, [0.1:0.25:max(PP_3)], 'LineWidth', 1.5,'LineColor','w','LineStyle',':');


axis xy
cmap = [
                 72 25 107
                 72 26 108
                 72 28 110
                 72 29 111
                 72 30 112   
                 72 32 113   
                 72 33 114   
                 72 34 115   
                 72 35 116  
                 71 36 116   
                 71 37 117   
                 71 38 117   
                 71 38 118   
                 71 42 121   
                 71 43 122   
                 71 44 123   
                 70 44 123   
                 70 45 124  
                 70 46 124   
                 70 47 124   
                 70 48 125   
                 70 49 126   
                 69 49 126   
                 69 50 127   
                 69 52 127   
                 69 53 128   
                 69 54 129  
                 68 54 129   
                 68 55 129   
                 68 56 129   
                 68 57 130   
                 67 57 130   
                 67 58 131   
                 67 59 131   
                 67 59 132   
                 67 60 132  
                 66 60 132   
                 66 61 132   
                 66 62 133  
                 66 63 133   
                 66 64 133
                 65 64 133
                 65 65 134 
                 65 66 134 
                 64 66 134  
                 64 67 135  
                 64 68 135   
                 63 68 135
                 63 69 135 
                 63 70 135 
                 63 71 136 
                 62 71 136
                 62 72 136 
                 62 73 137  
                 61 73 137
                 61 74 137
                 61 75 137 
                 61 76 137
                 60 77 138
                 60 78 138
                 59 79 138
                 59 80 138
                 59 81 138  
                 58 81 138
                 58 82 139 
                 58 83 139
                 57 83 139 
                 57 84 139 
                 57 85 139
                 56 85 139
                 56 86 139 
                 56 87 140  
                 55 88 140   
                 55 89 140   
                 54 89 140   
                 54 90 140   
                 53 91 140   
                 53 92 140   
                 53 93 140   
                 52 93 140   
                 52 94 141  
                 52 95 141    
                 51 95 141   
                 51 96 141   
                 50 97 141   
                 50 98 141   
                 50 99 141  
                 49 99 141   
                 49 100 141   
                 49 101 141  
                 49 102 141  
                 48 102 141   
                 48 103 141   
                 48 104 141   
                 47 104 141  
                 47 105 141   
                 46 106 141   
                 46 107 142   
                 46 108 142  
                 46 109 142  
                 45 109 142   
                 45 110 142   
                 44 111 142   
                 44 112 142   
                 44 113 142   
                 43 114 142   
                 43 115 142   
                 42 116 142   
                 42 117 142  
                 42 118 142   
                 41 119 142  
                 41 120 142  
                 40 121 142  
                 40 122 142  
                 39 123 142   
                 39 124 142  
                 38 126 142  
                 38 127 142  
                 38 128 142  
                 37 129 142   
                 37 130 141   
                 36 131 141   
                 36 132 141   
                 36 133 141   
                 35 134 141  
                 35 135 141   
                 35 136 141  
                 34 137 141   
                 34 138 141   
                 33 139 141   
                 33 140 140  
                 32 142 140   
                 32 143 140   
                 32 144 140  
                 31 145 140  
                 31 147 139  
                 31 148 139  
                 31 149 139   
                 30 150 138   
                 30 151 138   
                 30 152 138   
                 30 153 137  
                 30 155 137   
                 30 156 136  
                 30 157 136  
                 30 158 135  
                 30 160 135  
                 31 161 134  
                 31 163 133  
                 32 164 133  
                 32 165 133  
                 33 166 131  
                 34 167 130 
                 35 169 130  
                 36 170 129  
                 38 172 128  
                 39 173 127  
                 41 175 126  
                 43 177 125  
                 45 177 124 
                 47 179 122 
                 49 180 122  
                 53 183 119  
                 54 184 118  
                 57 185 117  
                 60 186 115  
                 63 188 114  
                 67 190 112  
                 70 191 110  
                 74 193 108 
                 75 193 106  
                 77 194 105  
                 78 194 105  
                 80 194 104  
                 81 196 103 
                 83 196 101   
                 84 197 102  
                 89 199 99   
                 95 201 96    
                 114 207 84 
                 120 208 81  
                 122 209 78 
                 125 209 77 
                 126 210 77  
                 144 213 64  
                 144 214 65  
                 149 215 62 
                 151 215 60 
                 155 216 57 
                 155 219 58   
                 159 217 55  
                 159 217 56  
                 160 217 55  
                 162 217 53   
                 162 217 54   
                 163 217 52  
                 164 218 52  
                 165 218 51  
                 166 218 50  
                 168 218 50   
                 171 219 47  
                 174 219 46  
                 174 220 46   
                 175 220 45  
                 193 222 34 
                 195 223 33 
                 197 223 32 
                 198 223 31 
                 199 223 30  
                 200 223 30  
                 200 224 31  
                 202 223 29  
                 202 224 28  
                 203 224 29   
                 204 224 28   
                 204 224 29   
                 206 223 28   
                 206 224 28  
                 226 227 24   
                 228 226 27   
                 229 227 26   
                 230 227 24   
                 231 227 25  
                 231 227 26   
                 234 228 26   
                 234 228 28  
                 237 228 25  
                 238 228 27  
                 239 228 28  
                 240 228 27 
                 240 229 28 
                 242 229 28   
                 243 229 29  
                 243 229 30   
                 244 229 31   
                 245 229 30  
                 252 230 36  
                 253 231 36 ];
cmap=cmap/255;
% colormap(peaks)
colormap(cmap)
% colorbar
% brighten(-.3);

hold on;
% 计算距离差为lambda倍的点

k_n = 10;
[X, Y] = meshgrid(x, y);

for i = -k_n:1:k_n
    func_1 = @(x, y) sqrt((charger1_x - x).^2 + (charger1_y - y).^2) - sqrt((charger2_x - x).^2 + (charger2_y - y).^2) - i*lambda;
    func_2 = @(x, y) sqrt((charger1_x - x).^2 + (charger1_y - y).^2) - sqrt((charger3_x - x).^2 + (charger3_y - y).^2) - i*lambda;
    func_3 = @(x, y) sqrt((charger2_x - x).^2 + (charger2_y - y).^2) - sqrt((charger3_x - x).^2 + (charger3_y - y).^2) - i*lambda;

    func1 = @(x, y) sqrt((charger1_x - x).^2 + (charger1_y - y).^2) - sqrt((charger2_x - x).^2 + (charger2_y - y).^2) - i*lambda/2;
    func2 = @(x, y) sqrt((charger1_x - x).^2 + (charger1_y - y).^2) - sqrt((charger3_x - x).^2 + (charger3_y - y).^2) - i*lambda/2;
    func3 = @(x, y) sqrt((charger2_x - x).^2 + (charger2_y - y).^2) - sqrt((charger3_x - x).^2 + (charger3_y - y).^2) - i*lambda/2;
    Z_1 = func_1(X, Y);
    Z_2 = func_2(X, Y);
    Z_3 = func_3(X, Y);

    Z1 = func1(X, Y);
    Z2 = func2(X, Y);
    Z3 = func3(X, Y);

    contour(X, Y, Z_1, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255]);
    contour(X, Y, Z_2, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255]);
    contour(X, Y, Z_3, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255]);

%     contour(X, Y, Z1, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255],'LineStyle','--');
%     contour(X, Y, Z2, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255],'LineStyle','--');
%     contour(X, Y, Z3, [0 0], 'LineWidth', 0.7,'LineColor',[227/255 208/255 179/255],'LineStyle','--');
%     hold on;
end
axis('equal');
%
sz=25;
% set(gca,'xtick',0:100:300);%横坐标间隔
% set(gca,'ytick',0:100:300);
% set(gca,'xticklabel',{'0m','1m','2m','3m'});
% set(gca,'yticklabel',{'','1m','2m','3m'});
set(gca, 'XTick', [], 'YTick', []); % 隐藏 x 和 y 轴的刻度和标签
set(gca,'FontSize',20,'FontName','Times New Roman');
hold off;

% xlabel('x (m)','Fontsize', 25,'FontName','Times New Roman');% x轴名称
% ylabel('y (m)','Fontsize', 25,'FontName','Times New Roman');
