%% 功率分布图
clear;
clc;
hold off;

map_length = 300;
map_width = 300;
charger_D = 150; % D表示充电器能够到达的最远距离
charger_alpha = 100;
charger_beta = 40;

chargers_x = randi([0,map_length],1,4);
chargers_y = randi([0,map_width],1,4);
% [X,Y] = meshgrid(0:map_length, 0:map_width);

object_P = @(x,y) sum(charger_alpha./((sqrt((chargers_x - x).^2 + (chargers_y - y).^2) + charger_beta).^2));
fmesh(object_P,[0 map_length 0 map_width]);
xlabel('X');
ylabel('Y');

%% 干涉波形
clear;
clc;
hold off;

phi_1 = 0;
phi_2 = 0.5*pi;
new_sin = @(x) 2*sin(x+phi_1) + sin(x+phi_2);
fplot(new_sin,[0,10*pi]);
xlabel('X');
ylabel('Y');

%% 波峰波谷同心圆
clear;
clc;
hold off;

figure;
axis equal; hold on;

centers = [0, 0; 
        5, 5];  % 圆心
radiis = zeros(2,4,2); % 半径
radiis(:,:,1) = [1, 2, 3, 4;
                0.5, 1.5, 2.5, 3.5]; % 第一个充电器
radiis(:,:,2) = [0.5, 1.5, 2.5, 3.5; 
                1, 2, 3, 4]; % 第二个充电器
theta = linspace(0, 2*pi, 100); % 角度采样点

% 定义三角形边长
side_length = 0.5;

for c = 1:size(centers,1)
    center = centers(c,:);
    rs = radiis(:,:,c);
    for r = rs(1,:)
        x = center(1) + r * cos(theta);
        y = center(2) + r * sin(theta);
        plot(x, y, 'r-', 'LineWidth', 1.5);
    end
    for r = rs(2,:)
        x = center(1) + r * cos(theta);
        y = center(2) + r * sin(theta);
        plot(x, y, 'b:', 'LineWidth', 1.5);
    end
    % 计算三角形三个顶点的坐标（等边三角形）
    height = side_length * sqrt(3) / 2; % 等边三角形高
    vertices_x = center(1) + [0, -side_length/2, side_length/2]; % x坐标
    vertices_y = center(2) + [height*2/3, -height/3, -height/3];    % y坐标
    patch(vertices_x, vertices_y, 'k', 'EdgeColor', 'none');
end

set(gca, 'XTick', [], 'YTick', []); % 隐藏 x 和 y 轴的刻度和标签
% title('波峰波谷同心圆');
xlim([-5, 10]); ylim([-5, 10]);

%% 靠近充电器的同心圆
clear;
clc;
hold off;

figure;
axis equal; hold on;

centers = [0, 0; 
        5, 5];  % 圆心
radiis = zeros(2,4,2); % 半径
radiis(:,:,1) = [1, 2, 3, 3.3;
                0.5, 1.5, 2.5, 3.5]; % 第一个充电器
radiis(:,:,2) = [0.5, 1.5, 2.5, 3.5; 
                1, 2, 3, 4]; % 第二个充电器
theta = linspace(0, 2*pi, 100); % 角度采样点

% 定义三角形边长
side_length = 0.5;

center = centers(1,:);
rs = radiis(1,:,1);
for r = rs(1:1)
    x = center(1) + r * cos(theta);
    y = center(2) + r * sin(theta);
    plot(x, y, 'r-', 'LineWidth', 1.5);
end
center = centers(2,:);
rs = radiis(:,:,2);
for r = 5.*rs(1,:)
    x = center(1) + r * cos(theta);
    y = center(2) + r * sin(theta);
    plot(x, y, 'r-', 'LineWidth', 1.5);
end
for r = 5.*rs(2,:)
    x = center(1) + r * cos(theta);
    y = center(2) + r * sin(theta);
    plot(x, y, 'b:', 'LineWidth', 1.5);
end
for c = 1:size(centers,1)
    center = centers(c,:);
    % 计算三角形三个顶点的坐标（等边三角形）
    height = side_length * sqrt(3) / 2; % 等边三角形高
    vertices_x = center(1) + [0, -side_length/2, side_length/2]; % x坐标
    vertices_y = center(2) + [height*2/3, -height/3, -height/3];    % y坐标
    patch(vertices_x, vertices_y, 'k', 'EdgeColor', 'none');
end

set(gca, 'XTick', [], 'YTick', []); % 隐藏 x 和 y 轴的刻度和标签
% title('波峰波谷同心圆');
xlim([-5, 10]); ylim([-5, 10]);