classdef ColorPrint
    methods (Static)
        function cprintf(text, color, style)
            % 参数声明块
            arguments
                text   % 必需参数
                color {mustBeText} = "black"
                style {mustBeText} = "normal"
            end

            % 支持颜色和样式
            % color: 'black', 'white', 'red', 'green', 'yellow', 'blue', 'magenta'（品红）,'cyan'（青色）,
            % color: 'k',     'w',     'r',   'g',     'y',      'b',    'm'（品红）,      'c'（青色）
            % style: 'normal', 'bold', 'underline', 'blink'
            
            % 颜色代码映射
            colorMap = containers.Map(...
                {'black', 'white', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan' ...
                 'k',     'w',     'r',   'g',     'y',      'b',    'm',       'c'}, ... % ...是续行符号
                {'30', '37', '31', '32', '33', '34', '35', '36' ...
                 '30', '37', '31', '32', '33', '34', '35', '36'});
            
            % 样式代码映射
            styleMap = containers.Map(...
                {'normal', 'bold', 'underline', 'blink'}, ...
                {'0', '1', '4', '5'});
            
            if isKey(colorMap, color) && isKey(styleMap, style)
                code = [char(27) '[' styleMap(style) ';' colorMap(color) 'm'];
                reset = [char(27) '[0m'];
                fprintf('%s%s%s\n', code, text, reset);
            else
                fprintf('%s\n', text);
            end
        end
        
        function printError(msg)
            fprintf('%s错误: %s%s\n', [char(27) '[1;31m'], msg, [char(27) '[0m']);
        end
        
        function printSuccess(msg)
            fprintf('%s成功: %s%s\n', [char(27) '[1;32m'], msg, [char(27) '[0m']);
        end
        
        function printWarning(msg)
            fprintf('%s警告: %s%s\n', [char(27) '[1;33m'], msg, [char(27) '[0m']);
        end
        
        function printInfo(msg)
            fprintf('%s信息: %s%s\n', [char(27) '[1;34m'], msg, [char(27) '[0m']);
        end
    end
end
